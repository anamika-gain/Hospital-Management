<?php

namespace App\Http\Controllers;
use DB;
use App\Models\RefCommission;
use Illuminate\Http\Request;
use DataTables;
class RefCommissionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    
    	return view('refcommission.ref_com');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function referralfilter(Request $request)
    {
        
        $data = DB::table('ref_commissions')
        ->select('referral_id', 'billing_id', 'date', 'amount', 'status')
        ->where('date', $request->date)
        ->where('referral_id', $request->id)
        ->get();
        return datatables()->of($data)->make(true); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\RefCommission  $refCommission
     * @return \Illuminate\Http\Response
     */
    public function show(RefCommission $refCommission)
    {
        //
    }

    public function edit(RefCommission $refCommission)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\RefCommission  $refCommission
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, RefCommission $refCommission)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\RefCommission  $refCommission
     * @return \Illuminate\Http\Response
     */
    public function destroy(RefCommission $refCommission)
    {
        //
    }
}
