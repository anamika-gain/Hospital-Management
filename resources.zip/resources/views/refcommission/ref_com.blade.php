@extends('layout.app')
@section('styles')
<link type="text/css" href="assets/css/themes/default/vendor-bootstrap-datatables.css" rel="stylesheet">
@endsection
@section('content')
<div class="container-fluid">
        <div class="card">
            <div class="card-header border-0">
                <h6 class="d-flex align-items-center justify-content-between card-title">
                    <span>Tickets</span>
                    <span>
                        <form id="searchForm" class="form-inline" style="text-align: center;padding-left:300px">
        
                            <div class="col-5 input-group date">
                                <input type="text" class="form-control" name="date" value="12-02-2012">
                                <div class="input-group-addon">
                                    <span class="material-icons" style="padding: 5px;">event</span>
                                </div>
                            </div>
                       
                            @php
                            $referral=DB::table('users')->where('role_id',"=",2)->get();
                            @endphp
                            <select class="form-control"   id="target" name="name">
                            <option>Select Referral</option>
                            @foreach($referral as $row)
                            <option class="form-control dropdown-item"  value="{{$row->name}}">{{$row->name}}</option>
                            @endforeach
                            </select>
                            <br>
                            <button type="submit" id="butsearch" class="btn btn-primary">Search</button>
                        </form>
                    </span>
                </h6>
            </div>
        
            <div class="card-body">
                <div class="table-responsive">
                    <table id="customer_data" class="table">
                        <thead>
                            <tr>
                      
                                <th scope="col" class="text-center">Bill Id</th>
                                <th scope="col" class="text-center">Referral Id</th>
                                <th scope="col" class="text-center">Amount</th>
                                <th scope="col" class="text-center">Date</th>
                                <th scope="col" class="text-center">Status</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                           
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
</div>
@endsection

@section('scripts')
<script src="assets/vendor/jquery.dataTables.js"></script>
<script src="assets/vendor/dataTables.bootstrap4.js"></script>
<script type="text/javascript">
    $(document).ready(function() {


  function fill_datatable()
    {
        var dataTable = $('#customer_data').DataTable({
            processing: true,
            serverSide: true,
            type: "GET",
            ajax:{
                url: "{{ route('referralfilter') }}",
                
            },
            columns: [
                {
                    data:'referral_id',
                    name:'referral_id'
                },
                {
                    data:'billing_id',
                    name:'billing_id'
                },
                {
                    data:'date',
                    name:'date'
                },
                {
                    data:'amount',
                    name:'amount'
                },
                {
                    data:'status',
                    name:'status'
                }
            ]
        });
    }
       
        $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
       });
        $('#butsearch').on('click', function(e) {
        e.preventDefault();
        $(this).html('Searching..');
            $.ajax({
                 data: $('#searchForm').serialize(),
                 url:  "{{ route('referralfilter') }}",
                 type: "POST",
                 success: function(data){
                     $('#searchForm').trigger("reset");
                
                     fill_datatable();
                 }
             });
          
        });
    });
      
</script>


@endsection
