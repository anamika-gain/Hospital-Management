<!DOCTYPE html>
<html lang="en" dir="ltr" class="theme-default">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>@yield('title')</title>


    <link type="text/css" href="{{asset('/')}}assets/css/themes/default/vendor-fullcalendar.css" rel="stylesheet">
    <link type="text/css" href="{{asset('/')}}assets/css/themes/default/vendor-weathericons.css" rel="stylesheet">
    <link type="text/css" href="{{asset('/')}}assets/css/themes/default/vendor-bootstrap-datepicker.css" rel="stylesheet">

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <!-- Simplebar -->
    <link type="text/css" href="{{asset('/')}}assets/vendor/simplebar.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="{{asset('/')}}assets/css/themes/default/app.css" rel="stylesheet">
    @yield('styles')

</head>

<body>
    <div class="d-flex flex-column position-relative h-100">

    @include('partial.topbar')

        <div class="mdk-drawer-layout js-mdk-drawer-layout" data-fullbleed data-push data-has-scrolling-region>
            <div class="mdk-drawer-layout__content mdk-header-layout__content--scrollable">
                <!-- CONTENT BODY -->

             @yield('content')

                    
            </div>
            @include('partial.sidebar')
          
    </div>

    <!-- jQuery -->
    <script src="{{asset('/')}}assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="{{asset('/')}}assets/vendor/popper.js"></script>
    <script src="{{asset('/')}}assets/vendor/bootstrap.min.js"></script>

    <!-- Simplebar -->
    <!-- Used for adding a custom scrollbar to the drawer -->
    <script src="{{asset('/')}}assets/vendor/simplebar.js"></script>


    <script src="{{asset('/')}}assets/vendor/moment.min.js"></script>
    <script src="{{asset('/')}}assets/vendor/dateformat.js"></script>
    <script src="{{asset('/')}}assets/vendor/bootstrap-datepicker.min.js"></script>

    <script>
        window.theme = "default";
    </script>
    <script src="{{asset('/')}}assets/js/color_variables.js"></script>
    <script src="{{asset('/')}}assets/js/app.js"></script>


    <script src="{{asset('/')}}assets/vendor/dom-factory.js"></script>
    <!-- DOM Factory -->
    <script src="{{asset('/')}}assets/vendor/material-design-kit.js"></script>
    <!-- MDK -->
    <script src="{{asset('/')}}assets/vendor/fullcalendar.min.js"></script>
    <script src="{{asset('/')}}assets/js/calendars.js"></script>
    <script src="{{asset('/')}}assets/js/datepicker.js"></script>



    <script>
        (function() {
            'use strict';

            // Self Initialize DOM Factory Components
            domFactory.handler.autoInit()

            // Connect button(s) to drawer(s)
            var sidebarToggle = Array.prototype.slice.call(document.querySelectorAll('[data-toggle="sidebar"]'))

            sidebarToggle.forEach(function(toggle) {
                toggle.addEventListener('click', function(e) {
                    var selector = e.currentTarget.getAttribute('data-target') || '#default-drawer'
                    var drawer = document.querySelector(selector)
                    if (drawer) {
                        drawer.mdkDrawer.toggle()
                    }
                })
            })

            //////////////////////////////////////////
            // BREAK OUT OF ENVATO LIVE DEMO IFRAME //
            //////////////////////////////////////////

            window.top.location.hostname !== window.location.hostname && (window.top.location = window.location)

        })();
    </script>



    {{-- <div class="modal fade" id="newTicketModal" tabindex="-1" role="dialog" aria-labelledby="newTicketModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newTicketModalLabel">Add a new ticket</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <div class="form-group">
                            <label for="description" class="mr-1">Description</label>
                            <input type="text" class="form-control" name="description" id="description" placeholder="Ticket description">
                        </div>
                        <div class="form-group">
                            <label for="description" class="mr-1">Status</label>
                            <select class="custom-select form-control">
              <option selected>None</option>
              <option value="1">Resolved</option>
              <option value="2">Active</option>
              <option value="3">Closed</option>
            </select>
                        </div>
                        <div class="form-group">
                            <label for="description" class="mr-1">Milestone</label>
                            <select class="custom-select form-control">
              <option selected>None</option>
              <option value="1">Initial Release</option>
              <option value="2">Alpha Release</option>
              <option value="3">Bug Fixes</option>
            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Add ticket</button>
                </div>
            </div>
        </div>
    </div> --}}


    <script src="{{asset('/')}}assets/vendor/fullcalendar.min.js"></script>
    <script src="{{asset('/')}}assets/js/calendars.js"></script>
    
    @yield('scripts')

    

</body>

</html>